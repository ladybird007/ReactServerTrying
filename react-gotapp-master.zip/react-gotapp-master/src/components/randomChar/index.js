import RandomChar from './randomChar';

export default RandomChar;