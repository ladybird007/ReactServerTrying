import App from './app';

export default App;
